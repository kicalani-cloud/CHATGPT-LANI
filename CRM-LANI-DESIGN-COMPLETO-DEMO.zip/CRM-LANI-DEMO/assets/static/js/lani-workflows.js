/* Local view controls; preserve existing server actions and permissions. */
(function () {
 'use strict';
 const workspace = document.querySelector('.lani-workspace');
 if (!workspace) return;
 // Name icon-only controls without changing handlers.
 workspace.querySelectorAll('button,a.btn').forEach(el => {
  if (el.textContent.trim() || el.hasAttribute('aria-label')) return;
  const icon=el.querySelector('i');
  const names={'bi-search':'Cerca','bi-pencil':'Modifica note','bi-download':'Scarica registrazione','bi-three-dots-vertical':'Altre azioni','bi-whatsapp':'Apri WhatsApp','bi-trash':'Elimina','bi-chevron-left':'Mese precedente','bi-chevron-right':'Mese successivo'};
  for (const [cls,name] of Object.entries(names)) if(icon?.classList.contains(cls)) {el.setAttribute('aria-label',name);el.title ||= name;break;}
 });
 workspace.querySelectorAll('[id^="kpi-"][onclick]').forEach(el=>{
  el.tabIndex=0;el.setAttribute('role','button');el.setAttribute('aria-pressed','false');
  el.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();el.click();}});
 });
 const search = document.getElementById('lani-cb-search');
 if (!search) return;
 const size=document.getElementById('lani-cb-size');const count=document.getElementById('lani-cb-count');
 const states=[...workspace.querySelectorAll('.tab-pane')].map(pane=>{
  const rows=[...pane.querySelectorAll('tbody tr')];
  const footer=document.createElement('div');footer.className='lani-work-pager';
  const info=document.createElement('span');info.setAttribute('role','status');
  const controls=document.createElement('div');
  const prev=document.createElement('button'),next=document.createElement('button');
  for(const el of [prev,next]){el.type='button';el.className='btn btn-outline-secondary';}
  prev.textContent='← Precedente';next.textContent='Successiva →';controls.append(prev,next);footer.append(info,controls);pane.append(footer);
  const state={pane,rows,page:1,info,prev,next};
  prev.addEventListener('click',()=>{state.page--;render();});next.addEventListener('click',()=>{state.page++;render();});return state;
 });
 function render(){
  const q=search.value.toLocaleLowerCase('it').trim();const n=Number(size.value);
  for(const s of states){
   const found=s.rows.filter(r=>r.textContent.toLocaleLowerCase('it').includes(q));const pages=Math.max(1,Math.ceil(found.length/n));
   s.page=Math.max(1,Math.min(s.page,pages));s.rows.forEach(r=>r.hidden=true);
   found.slice((s.page-1)*n,s.page*n).forEach(r=>r.hidden=false);
   s.info.textContent=found.length ? `${(s.page-1)*n+1}–${Math.min(s.page*n,found.length)} di ${found.length} clienti` : 'Nessun cliente trovato';
   s.prev.disabled=s.page===1;s.next.disabled=s.page===pages;
   if(s.pane.classList.contains('active'))count.textContent=found.length+' clienti nel segmento';
  }
 }
 for(const el of [search,size])el.addEventListener(el===search?'input':'change',()=>{states.forEach(s=>s.page=1);render();});
 workspace.addEventListener('shown.bs.tab',render);render();
})();
