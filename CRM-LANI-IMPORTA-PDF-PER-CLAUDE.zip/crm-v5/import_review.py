"""Read-only customer match for the PDF review screen, using save's exact identity keys."""
from flask import Blueprint, jsonify, request, url_for
from flask_login import login_required
from models import Cliente

review = Blueprint('import_review', __name__)

@review.get('/api/importa-pdf/cliente')
@login_required
def customer_match():
    cf = (request.args.get('cf') or '').strip()
    piva = (request.args.get('piva') or '').strip()
    if not (piva or cf):
        return jsonify(status='missing', message='Inserisci codice fiscale o partita IVA.')
    # Same priority and exact comparison as importa_pdf_salva. Never fuzzy-match a phone number.
    query = Cliente.query.filter_by(partita_iva=piva) if piva else Cliente.query.filter_by(codice_fiscale=cf)
    matches = query.limit(2).all()
    if len(matches) > 1:
        return jsonify(status='ambiguous', message='Più schede con lo stesso identificativo: verifica i duplicati prima di importare.')
    if not matches:
        return jsonify(status='new', message='Nessuna corrispondenza: verrà creata una nuova scheda cliente.')
    client = matches[0]
    return jsonify(status='matched', name=client.nome_completo, url=url_for('cliente_dettaglio', id=client.id), message='Cliente già presente: il contratto verrà collegato alla scheda.')

def register(app):
    app.register_blueprint(review)
