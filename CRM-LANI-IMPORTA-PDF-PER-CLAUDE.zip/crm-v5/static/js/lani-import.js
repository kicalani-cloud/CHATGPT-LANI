(function(){
 'use strict';
 const controllerUrl=document.currentScript.src;
 const $=id=>document.getElementById(id),root=$('lani-import'),form=$('form-importa');if(!root||!form)return;
 const sheet=document.querySelector('link[href*="lani-import.css"]');if(sheet)document.head.append(sheet);
 let stage=0,docEpoch=0,requestId=0,pdfUrl='',busy=false,matchState='missing',matchSequence=0,matchTimer,aiProposal=null;
 const originalSave=window.validaESalva;
 const value=id=>$(id)?.value.trim()||'';
 function node(tag,cls,text){const el=document.createElement(tag);if(cls)el.className=cls;if(text!==undefined)el.textContent=text;return el;}
 function error(text){$('li-error').textContent=text;$('li-error').classList.toggle('d-none',!text);}
 function setStage(n){stage=n;root.dataset.stage=n;document.querySelectorAll('[data-li-step]').forEach(el=>{const i=Number(el.dataset.liStep);el.classList.toggle('current',i===n);el.classList.toggle('done',i<n);if(i===n)el.setAttribute('aria-current','step');else el.removeAttribute('aria-current');});$('step-upload').classList.toggle('d-none',n!==0);$('step-preview').classList.toggle('d-none',n===0);for(const id of ['li-customer','li-contract','li-device','li-ai-card'])$(id)?.classList.toggle('li-step-hidden',n===2);$('li-review').classList.toggle('d-none',n!==2);$('li-next').innerHTML=n===2?'Conferma e importa <i class="bi bi-arrow-right"></i>':'Rivedi e conferma <i class="bi bi-arrow-right"></i>';$('li-back').textContent=n===2?'Modifica dati':'Cambia PDF';}
 function disclosure(card,title,ids){
  const body=card?.querySelector('.card-body');if(!body)return;
  const keep=new Set(ids.map(id=>{let el=$(id);while(el&&el.parentElement!==body)el=el.parentElement;return el;}));
  const children=[...body.children].filter(x=>!keep.has(x));if(!children.length)return;
  const d=node('details','li-extra'),summary=node('summary','',title),content=node('div','row g-2');d.append(summary,content);children.forEach(x=>content.append(x));body.append(d);
 }
 disclosure($('li-customer'),'Indirizzo, pagamento e altri dati cliente',['f_tipo','campi-privato','campi-business','f_tel','f_email']);
 disclosure($('li-contract'),'Classificazione, date e impostazioni aggiuntive',['f_piano','f_canone','f_nlin','f_iccid','box-cluster-cb','box-evento-cb','box-opzioni-mobile','box-opzioni-fisso','box-luce-gas','box-doppio-lg','box-convergenza']);
 $('f_piano').parentElement.after($('f_canone').parentElement);
 const device=$('f_imei').closest('.card');device.id='li-device';
 const clientStatus=node('div','li-client-status');clientStatus.id='li-client-status';$('li-customer').querySelector('.card-body').prepend(clientStatus);
 const clientBody=$('li-customer').querySelector('.card-body');const edit=node('details','li-client-edit');const editSummary=node('summary','','Controlla o modifica anagrafica');edit.append(editSummary);const editRows=node('div','row g-2');[...clientBody.children].filter(el=>el!==clientStatus).forEach(el=>editRows.append(el));edit.append(editRows);const identity=node('div','li-client-identity');identity.id='li-client-identity';clientBody.append(identity,edit);

 // Clear distinctions without adding a mandatory operation selector.
 const lineLabel=$('f_nlin').parentElement.querySelector('label');lineLabel.textContent='Numero linea / nuova SIM';$('f_nport').parentElement.querySelector('label').textContent='Numero da portare (MNP)';
 const notes=node('div','li-checks');notes.id='li-checks';$('li-ai-card').before(notes);
 const confirm=node('div','form-check mt-3');const acknowledge=node('input','form-check-input');acknowledge.type='checkbox';acknowledge.id='li-acknowledge';const ackLabel=node('label','form-check-label','Ho controllato i dati e la data di attivazione con il documento.');ackLabel.htmlFor=acknowledge.id;confirm.append(acknowledge,ackLabel);
 function operation(){const type=value('f_tipo_contratto'),cat=value('f_categoria'),phone=$('f_tel_incluso').checked||value('f_imei');if(type==='fisso')return value('f_tipo_acquisizione_fisso')==='nuovo'?'Fisso · Nuova linea':'Fisso · '+($('f_tipo_acquisizione_fisso').selectedOptions[0]?.textContent||'');if(['luce','gas','luce_gas','assicurazione','antifurto'].includes(type))return {luce:'Luce',gas:'Gas',luce_gas:'Luce + Gas',assicurazione:'Assicurazione',antifurto:'Antifurto'}[type];if(cat==='sim_sostitutiva')return 'Sostituzione SIM';if(cat==='cambio_metodo_pagamento')return 'Cambio metodo di pagamento';if(cat==='cb')return phone?'Customer Base + telefono':'Customer Base';return value('f_nport')?'Mobile · MNP':'Mobile';}
 function refresh(){
  identity.replaceChildren();const name=value('f_tipo')==='business'?value('f_rs'):[value('f_nome'),value('f_cognome')].filter(Boolean).join(' ');const avatar=node('span','li-avatar',(name||'?').slice(0,1));const copy=node('div');copy.append(node('strong','',name||'Cliente da completare'),node('span','',value('f_piva')||value('f_cf')||'Identificativo da completare'));identity.append(avatar,copy);
  const summary=$('li-live-summary');summary.replaceChildren();summary.append(node('span','li-chip orange',operation()));
  if(value('f_categoria')==='tied')summary.append(node('span','li-chip purple','Easy Pay / addebito automatico'));
  if(value('f_categoria')==='cb'&&value('f_evento_cb'))summary.append(node('span','li-chip blue',$('f_evento_cb').selectedOptions[0]?.textContent.split('—')[0].trim()));
  const phone=!!($('f_tel_incluso').checked||value('f_imei')||value('f_modello'));device.hidden=!phone;
  const simChange=value('f_categoria')==='sim_sostitutiva';const mobile=value('f_tipo_contratto')==='mobile';lineLabel.textContent=value('f_categoria')==='cb'||simChange?'Numero linea esistente':'Numero linea / nuova SIM';
  // These two fields belong to mobile options; parent display is controlled by the original CRM.
  $('f_nport').parentElement.classList.toggle('li-not-relevant',value('f_categoria')==='cb'||simChange);
  $('f_opprec').parentElement.classList.toggle('li-not-relevant',value('f_categoria')==='cb'||simChange);
  $('f_iccid').parentElement.classList.toggle('li-not-relevant',!mobile);
  notes.replaceChildren();notes.append(node('strong','','Prima di importare'));
  const list=node('ul');const issues=[];
  if(!value('f_cf')&&!value('f_piva'))issues.push('Completa codice fiscale o partita IVA per collegare il cliente.');
  if(!value('f_piano'))issues.push('Offerta non rilevata: controlla il documento.');
  issues.push(value('f_datt')?'Controlla che la data proposta sia l’attivazione effettiva, non solo la firma.':'La data di attivazione non è indicata.');
  if(value('f_categoria')==='cb')issues.push('Verifica evento CB e linea esistente: i punti seguono le regole CB del CRM.');
  if(value('f_nport'))issues.push('Numero da portare e numero della nuova SIM restano separati.');
  issues.forEach(text=>list.append(node('li','',text)));notes.append(list);
 }
 async function checkCustomer(){
  const seq=++matchSequence,cf=value('f_cf'),piva=value('f_piva');matchState='checking';const badge=$('li-client-badge');badge.textContent='Verifica scheda…';clientStatus.replaceChildren(node('span','','Ricerca per codice fiscale o partita IVA…'));
  try{
   const response=await fetch('/api/importa-pdf/cliente?'+new URLSearchParams({cf,piva}),{credentials:'same-origin'});if(!response.ok)throw new Error();const data=await response.json();if(seq!==matchSequence)return;
   matchState=data.status||'unavailable';badge.textContent={matched:'Già presente nel CRM',new:'Nuovo cliente',missing:'Da identificare',ambiguous:'Duplicati da verificare'}[matchState]||'Verifica al salvataggio';badge.classList.toggle('matched',matchState==='matched');clientStatus.replaceChildren(node('span','',data.message||'La scheda viene verificata al salvataggio.'));
   if(matchState==='matched'&&data.url?.startsWith('/clienti/')){const a=node('a','','Apri scheda →');a.href=data.url;a.target='_blank';a.rel='noopener';clientStatus.append(a);}
  }catch{if(seq!==matchSequence)return;matchState='unavailable';badge.textContent='Verifica al salvataggio';clientStatus.replaceChildren(node('span','','Ricerca non disponibile. Il salvataggio conserva il controllo cliente esistente.'));}
 }
 function updatePrice(from){const other=from==='f_prezzo_dev'?'f_prezzo_sp':'f_prezzo_dev';$(other).value=$(from).value;window.aggiornaGettoneDevice?.();window.aggiornaPuntiGA?.();}
 for(const id of ['f_prezzo_dev','f_prezzo_sp'])$(id).addEventListener('input',()=>updatePrice(id));
 let demoPages=[],pdfDoc=null,pdfTask=null,renderTask=null,pdfPage=1,pdfZoom=1,pdfVersion=0,drawVersion=0;
 function clearPdf(){++pdfVersion;++drawVersion;if(renderTask){renderTask.cancel();renderTask=null;}if(pdfTask){pdfTask.destroy().catch(()=>{});pdfTask=null;}pdfDoc=null;demoPages=[];$('li-pdf-image').hidden=true;pdfPage=1;pdfZoom=1;$('li-pdf-canvas').hidden=true;$('li-pdf-message').hidden=false;$('li-pdf-message').textContent='Anteprima del documento';$('li-page-count').textContent='—';}
 async function renderPdf(url){
  const version=pdfVersion;if(demoPages.length){pdfDoc={numPages:demoPages.length};return drawPdf();}$('li-pdf-message').hidden=false;$('li-pdf-message').textContent='Caricamento anteprima…';
  try{const lib=await import(new URL('../vendor/pdfjs/pdf.mjs',controllerUrl));if(version!==pdfVersion)return;lib.GlobalWorkerOptions.workerSrc=new URL('../vendor/pdfjs/pdf.worker.mjs',controllerUrl).href;pdfTask=lib.getDocument({url:new URL(url,location.href).href,isEvalSupported:false});const doc=await pdfTask.promise;if(version!==pdfVersion)return;pdfDoc=doc;await drawPdf();}
  catch(e){if(version===pdfVersion){$('li-pdf-message').hidden=false;$('li-pdf-message').textContent='Anteprima non disponibile. Usa “Apri PDF” per consultare il documento.';}}
 }
 async function drawPdf(){
  if(!pdfDoc)return;if(demoPages.length){const img=$('li-pdf-image');img.src=new URL(demoPages[pdfPage-1],location.href).href;img.style.width=(Math.max(220,$('li-pdf-surface').clientWidth-24)*pdfZoom)+'px';img.hidden=false;$('li-pdf-canvas').hidden=true;$('li-pdf-message').hidden=true;$('li-page-count').textContent=pdfPage+' / '+pdfDoc.numPages;$('li-zoom').textContent=Math.round(pdfZoom*100)+'%';$('li-page-prev').disabled=pdfPage<=1;$('li-page-next').disabled=pdfPage>=pdfDoc.numPages;return;}const version=pdfVersion,draw=++drawVersion;if(renderTask){renderTask.cancel();renderTask=null;}
  try{const page=await pdfDoc.getPage(pdfPage);if(version!==pdfVersion||draw!==drawVersion)return;const natural=page.getViewport({scale:1});const width=Math.max(220,$('li-pdf-surface').clientWidth-24);const scale=width/natural.width*pdfZoom;const viewport=page.getViewport({scale});const canvas=$('li-pdf-canvas');const ratio=window.devicePixelRatio||1;canvas.width=viewport.width*ratio;canvas.height=viewport.height*ratio;canvas.style.width=viewport.width+'px';canvas.style.height=viewport.height+'px';canvas.hidden=false;$('li-pdf-message').hidden=true;renderTask=page.render({canvasContext:canvas.getContext('2d'),viewport,transform:ratio===1?null:[ratio,0,0,ratio,0,0]});await renderTask.promise;if(draw!==drawVersion)return;renderTask=null;$('li-page-count').textContent=pdfPage+' / '+pdfDoc.numPages;$('li-zoom').textContent=Math.round(pdfZoom*100)+'%';$('li-page-prev').disabled=pdfPage<=1;$('li-page-next').disabled=pdfPage>=pdfDoc.numPages;$('li-zoom-out').disabled=pdfZoom<=.75;$('li-zoom-in').disabled=pdfZoom>=1.75;}
  catch(e){if(e.name!=='RenderingCancelledException'&&version===pdfVersion){$('li-pdf-message').hidden=false;$('li-pdf-message').textContent='Usa “Apri PDF” per consultare il documento.';}}
 }
 $('li-page-prev').addEventListener('click',()=>{if(pdfDoc&&pdfPage>1){--pdfPage;drawPdf();}});$('li-page-next').addEventListener('click',()=>{if(pdfDoc&&pdfPage<pdfDoc.numPages){++pdfPage;drawPdf();}});$('li-zoom-out').addEventListener('click',()=>{pdfZoom=Math.max(.75,pdfZoom-.25);drawPdf();});$('li-zoom-in').addEventListener('click',()=>{pdfZoom=Math.min(1.75,pdfZoom+.25);drawPdf();});let resizeTimer;window.addEventListener('resize',()=>{clearTimeout(resizeTimer);resizeTimer=setTimeout(drawPdf,150);});
 function release(){clearPdf();if(pdfUrl.startsWith('blob:'))URL.revokeObjectURL(pdfUrl);pdfUrl='';}
 function reset(){++docEpoch;++requestId;++matchSequence;clearTimeout(matchTimer);busy=false;release();form.reset();$('pdf-input').value='';$('pdf-input').disabled=false;$('upload-status').replaceChildren();$('ai-verifica-result').replaceChildren();$('ai-verifica-result').style.display='none';aiProposal=null;error('');setStage(0);}
 async function load(file){
  if(!file||!file.name.toLowerCase().endsWith('.pdf')){error('Seleziona un documento PDF.');return;}
  if(busy)return;const req=++requestId;busy=true;error('');$('pdf-input').disabled=true;$('upload-status').replaceChildren(node('span','li-loading','Lettura del documento in corso…'));
  try{
   const fd=new FormData();fd.append('pdf',file);const response=await fetch('/contratti/upload-pdf',{method:'POST',body:fd,credentials:'same-origin'});
   if(!response.ok)throw new Error(response.status===413?'Il PDF supera il limite del server.':'Impossibile leggere il PDF. Riprova o verifica l’accesso al CRM.');const data=await response.json();if(req!==requestId)return;if(data.error)throw new Error(data.error);
   loaded(data,file.name,URL.createObjectURL(file));
  }catch(e){if(req===requestId){error(e.message||'Lettura non riuscita.');$('upload-status').replaceChildren();}}
  finally{if(req===requestId){busy=false;$('pdf-input').disabled=false;}}
 }
 function loaded(data,name,url,pages){
  ++docEpoch;$('btn-verifica-ai').disabled=false;$('btn-verifica-ai').innerHTML='<i class="bi bi-stars me-1"></i>Verifica';release();form.reset();window.compilaForm(data);if(value('f_prezzo_dev'))updatePrice('f_prezzo_dev');pdfUrl=url||'';demoPages=Array.isArray(pages)?pages:[];$('li-file-name').textContent=name||'Contratto PDF';if(pdfUrl){renderPdf(pdfUrl);$('li-open-pdf').href=pdfUrl;$('li-open-pdf').hidden=false;}else{$('li-open-pdf').hidden=true;}
  $('upload-status').replaceChildren();$('ai-verifica-result').replaceChildren();$('ai-verifica-result').style.display='none';aiProposal=null;acknowledge.checked=false;error('');setStage(1);refresh();edit.open=!(value('f_cf')||value('f_piva'));checkCustomer();window.scrollTo({top:0,behavior:'smooth'});
 }
 function addReview(label,text){const row=node('div','li-review-row');row.append(node('span','',label),node('strong','',text||'Non indicato'));$('li-review-content').append(row);}
 function review(){
  const customer=value('f_tipo')==='business'?value('f_rs'):[value('f_nome'),value('f_cognome')].filter(Boolean).join(' ');
  if(!customer){error('Completa il nome del cliente o la ragione sociale.');$('li-customer').scrollIntoView({block:'start',behavior:'smooth'});return;}
  if(value('f_categoria')==='cb'&&value('f_tipo_contratto')==='mobile'&&!value('f_evento_cb')&&!$('f_tel_incluso').checked){error('Controlla l’evento CB prima di procedere.');$('f_evento_cb').focus();return;}
  if(matchState==='ambiguous'){error('Ci sono schede duplicate con lo stesso identificativo. Verificale prima di salvare.');return;}
  const body=$('li-review-content');body.replaceChildren();addReview('Cliente',customer);addReview('CF / P.IVA',value('f_piva')||value('f_cf'));addReview('Operazione',operation());addReview('Offerta',value('f_piano'));addReview('Canone base',value('f_canone')?Number(value('f_canone')).toLocaleString('it-IT',{style:'currency',currency:'EUR'})+' / mese':'Non indicato');addReview('Linea / SIM',value('f_nlin'));if(value('f_nport'))addReview('Numero da portare',value('f_nport'));addReview('Data attivazione proposta',value('f_datt'));if(!device.hidden)addReview('Telefono',[value('f_marca'),value('f_modello')].filter(Boolean).join(' '));
  body.append(confirm);acknowledge.checked=false;error('');setStage(2);window.scrollTo({top:0,behavior:'smooth'});
 }
 $('li-next').addEventListener('click',async()=>{
  if(stage!==2){review();return;}
  if(!acknowledge.checked){error('Conferma di avere controllato i dati prima del salvataggio.');acknowledge.focus();return;}
  if(matchState==='ambiguous'){error('Verifica le schede duplicate prima di salvare.');return;}
  if(matchState==='checking'){error('Attendi il controllo della scheda cliente.');return;}
  error('');originalSave();
 });
 $('li-back').addEventListener('click',()=>{if(stage===2){error('');setStage(1);}else if(confirmDiscard())reset();});
 function confirmDiscard(){return stage===0||window.confirm('Cambiare documento? Le modifiche non salvate verranno perse.');}
 $('li-cancel').addEventListener('click',()=>{if(confirmDiscard())reset();});
 window.caricaPDF=load;window.resetUpload=()=>{if(confirmDiscard())reset();};
 // Used by the standalone offline preview to supply synthetic data without contacting a server.
 window.addEventListener('lani:import-preview',event=>loaded(event.detail.data,event.detail.name,event.detail.url,event.detail.pages));
 form.addEventListener('input',()=>{acknowledge.checked=false;refresh();});
 form.addEventListener('change',()=>{acknowledge.checked=false;refresh();});
 for(const id of ['f_cf','f_piva'])$(id).addEventListener('input',()=>{matchState='checking';++matchSequence;clearTimeout(matchTimer);matchTimer=setTimeout(checkCustomer,350);});
 window.addEventListener('beforeunload',release);
 window.verificaConAI=async function(){
  const epoch=docEpoch,path=value('f_pdf_path');if(!path)return;const btn=$('btn-verifica-ai'),result=$('ai-verifica-result');btn.disabled=true;btn.textContent='Verifica in corso…';result.style.display='';result.replaceChildren(node('span','','Analisi del documento…'));
  try{const response=await fetch('/contratti/verifica-ai-pdf',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({pdf_path:path})});if(!response.ok)throw new Error('Verifica AI non disponibile.');const d=await response.json();if(epoch!==docEpoch)return;if(d.error)throw new Error(d.error);aiProposal=d;result.replaceChildren(node('strong','','Proposta AI · non ancora applicata'));
   const list=node('ul');for(const [key,label] of [['tipo_contratto','Tipo'],['categoria','Categoria'],['tipo_cliente','Cliente'],['piano','Offerta'],['nota','Nota']])if(d[key])list.append(node('li','',label+': '+d[key]));result.append(list);
   const apply=node('button','btn btn-sm btn-primary','Applica proposta');apply.type='button';apply.addEventListener('click',()=>{for(const [key,id] of [['tipo_contratto','f_tipo_contratto'],['categoria','f_categoria'],['tipo_cliente','f_tipo'],['piano','f_piano']]){const el=$(id);if(aiProposal[key]&&el){if(el.tagName==='SELECT'&&![...el.options].some(o=>o.value===aiProposal[key]))continue;el.value=aiProposal[key];}}
    window.toggleTipoContratto(value('f_tipo_contratto'));window.toggleCB(value('f_categoria'));window.toggleTipoCliente(value('f_tipo'));window.aggiornaPuntiGA?.();refresh();checkCustomer();result.replaceChildren(node('span','','Proposta applicata. Controlla i dati prima di salvare.'));});result.append(apply);
  }catch(e){if(epoch!==docEpoch)return;result.replaceChildren(node('span','text-danger',e.message||'Errore nella verifica AI.'));}finally{if(epoch===docEpoch){btn.disabled=false;btn.innerHTML='<i class="bi bi-stars me-1"></i>Verifica';}}
 };
 const drop=$('drop-area');drop.tabIndex=0;drop.setAttribute('role','button');drop.setAttribute('aria-label','Seleziona il contratto PDF');drop.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();$('pdf-input').click();}});
 form.querySelectorAll('button:not([type])').forEach(btn=>btn.type='button');
 form.addEventListener('submit',e=>{e.preventDefault();if(stage!==2)review();});
 setStage(0);
})();
