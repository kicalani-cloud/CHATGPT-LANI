# Otto pagine operative — grafica approvata

Questa consegna è cumulativa: include anche dashboard, grafici e layout comune della precedente consegna. Leggi LEGGIMI-PER-CLAUDE.md per il piccolo collegamento della dashboard ad app.py. Il CRM online non è stato modificato.

## Istruzione per Claude Code
Crea un backup e confronta i file con la versione attuale prima di integrarli. Unisci i template e gli asset, mantenendo tutte le modifiche funzionali successive. Non sostituire il backend, i modelli, le credenziali o il database. Se la dashboard precedente è già integrata, non applicare due volte app-dashboard.patch.

Le otto pagine aggiornate sono Customer Base, Rinnovi / Scadenze, Lead Caldi, Da Chiamare, Canvass Mensile, Report Mensile, Chiamate dal Cellulare e Clienti MyWCM. Ognuna include lani-workflows.css e lani-workflows.js; questi due file sono necessari. Gli stili sono circoscritti alla sezione lani-workspace.

- Customer Base: ricerca nel segmento e paginazione 25/50/100 righe, contatore risultati, filtri segmento e azioni conservate. La ricerca opera sulle righe rese dal server per il segmento.
- Rinnovi: ricerca testo e filtro urgenza agiscono insieme; KPI accessibili anche da tastiera; azioni compatte.
- Da Chiamare: pulsanti di dimensione coerente e descrizione corretta dei giorni già scaduti.
- Lead Caldi: schede compatte con prodotti attivi, opportunità e azioni affiancati; filtri allineati.
- MyWCM: filtri avanzati apribili, automaticamente aperti quando un filtro avanzato è attivo; tabella e barra comandi più ordinate.
- Canvass: intestazioni leggibili, riepilogo chiaro e card soglie coordinate.
- Report Mensile: filtri, riepilogo e tabella compatti.
- Chiamate: tabella e player compatti, controlli esistenti conservati. Nessun esito di chiamata viene dedotto artificialmente dalla durata.

Verifica su una copia del CRM: otto pagine autenticate, ricerca Customer Base e cambio segmento/pagina, Rinnovi con ricerca+urgenza, MyWCM con filtri attivi, modali e ruoli titolare/addetto. Verifica le azioni di scrittura solo con dati di prova. I controlli grafici sono stati eseguiti su 90 viste desktop e mobile; invii WhatsApp, analisi AI, telefonate reali e registrazioni audio reali non sono stati eseguiti.

Nessun database o dato cliente reale è incluso. La demo offline usa dati sintetici; filtri server, salvataggi e integrazioni richiedono il CRM. Nessuna migrazione o nuova dipendenza è richiesta da queste otto pagine.
