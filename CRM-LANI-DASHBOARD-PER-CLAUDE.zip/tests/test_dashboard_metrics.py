import sys,unittest
from datetime import date,datetime
from types import SimpleNamespace as N
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'crm'))
from dashboard_metrics import variation,comparison_windows,summarize_contracts,shift_month,build_dashboard_metrics
class Metrics(unittest.TestCase):
 def test_signed_change(self):
  self.assertEqual(variation(80,100)['text'],'−20%')
  self.assertEqual(variation(120,100)['text'],'+20%')
  self.assertEqual(variation(100,100)['text'],'0%')
  self.assertEqual(variation(0,100)['text'],'−100%')
  self.assertEqual(variation(100,0)['text'],'Nuovo')
  self.assertIsNone(variation(100,0)['percent'])
  self.assertEqual(variation(0,0)['text'],'0%')
  self.assertEqual(variation(99999,100000)['text'],'−<0,1%')
  self.assertEqual(variation(1,4)['kind'],'down')
 def test_equal_elapsed_days(self):
  a,b,c,d,mode=comparison_windows(date(2026,10,1),date(2026,10,17))
  self.assertEqual((a,b,c,d,mode),(date(2026,10,1),date(2026,10,18),date(2026,9,1),date(2026,9,18),'partial'))
 def test_clamp_and_leap_year(self):
  self.assertEqual(comparison_windows(date(2024,3,1),date(2024,3,31))[3],date(2024,3,1))
  self.assertEqual(comparison_windows(date(2025,3,1),date(2025,3,31))[3],date(2025,3,1))
  self.assertEqual(shift_month(date(2026,1,1),-1),date(2025,12,1))
 def test_closed_and_future(self):
  self.assertEqual(comparison_windows(date(2026,9,1),date(2026,10,17)),(date(2026,9,1),date(2026,10,1),date(2026,8,1),date(2026,9,1),'complete'))
  self.assertEqual(comparison_windows(date(2026,11,1),date(2026,10,17))[-1],'future')
  self.assertEqual(variation(0,10,True)['text'],'Non iniziato')
 def test_dates_points_and_status_rules(self):
  def record(**kw):
   d=dict(data_attivazione=date(2026,10,10),created_at=datetime(2026,9,1),categoria='undited',tipo='mobile',stato='attivo',punti_ga=.75);d.update(kw);return N(**d)
  data=[record(),record(categoria='cb',punti_ga=2),record(tipo='luce',punti_ga=0),record(stato='cessato'),record(categoria='sim_sostitutiva',punti_ga=0),record(data_attivazione=None,created_at=datetime(2026,10,31,23,59,59)),record(data_attivazione=date(2026,11,1))]
  v=summarize_contracts(data,date(2026,10,1),date(2026,11,1))
  self.assertEqual(v['ga']['mobile'],1.5);self.assertEqual(v['ga']['luce_gas'],1)
  self.assertEqual(v['cb']['mobile'],2);self.assertEqual(v['activations'],3)
 def test_database_periods_and_month_boundary(self):
  from flask import Flask
  from models import db,Cliente,Contratto,Utente
  app=Flask('metrics-tests');app.config.update(SQLALCHEMY_DATABASE_URI='sqlite://',SQLALCHEMY_TRACK_MODIFICATIONS=False);db.init_app(app)
  with app.app_context():
   db.create_all();u=Utente(nome='Demo',username='metrics-test',password_hash='test-only-not-a-real-account',ruolo='titolare');c=Cliente(tipo='privato',nome='Demo',created_at=datetime(2026,10,10));db.session.add_all([u,c]);db.session.flush()
   for stamp in [date(2026,9,10),date(2026,9,11),date(2026,9,25),date(2026,10,10),date(2026,10,25)]:
    db.session.add(Contratto(cliente_id=c.id,addetto_id=u.id,tipo='mobile',categoria='undited',stato='attivo',data_attivazione=stamp))
   db.session.add(Contratto(cliente_id=c.id,addetto_id=u.id,tipo='fisso',categoria='cb',stato='attivo',evento_cb='mig_ftth',data_attivazione=None,created_at=datetime(2026,10,31,23,59)))
   db.session.commit()
   v=build_dashboard_metrics(date(2026,10,1),date(2026,10,17))
   self.assertEqual(v['comparisons']['mobile']['text'],'−50%')
   self.assertEqual(v['current']['activations'],1);self.assertEqual(v['previous']['activations'],2)
   self.assertEqual(v['ga_series']['mobile'][-2],2.25);self.assertEqual(v['ga_series']['mobile'][-1],.75)
   full=build_dashboard_metrics(date(2026,10,1),date(2026,11,2))
   self.assertEqual(full['current']['cb']['fisso'],Contratto.PUNTI_CB['mig_ftth'])
   jan=build_dashboard_metrics(date(2027,1,1),date(2027,2,2));self.assertEqual(jan['full_labels'][-2],'Dic 2026')
   db.session.remove();db.drop_all()
if __name__=='__main__':unittest.main(verbosity=2)
