/* Presentation only: keep the original quote builder, pricing and POST fields. */
(function(){
 'use strict';const root=document.getElementById('lani-quote');if(!root)return;
 const sheet=document.querySelector('link[href*="lani-quote.css"]');if(sheet)document.head.append(sheet);
 const main=root.querySelector('.lq-main'),aside=root.querySelector('.lq-aside');
 main.querySelectorAll(':scope>.kol-section').forEach(section=>{
  const header=section.querySelector(':scope>.kol-label');if(!header)return;
  const title=header.textContent.trim();const icon=document.createElement('i');icon.className='bi bi-'+(section.id==='lq-client'?'person-badge-fill':title.includes('Note')?'journal-text':title.includes('Servizi nel')?'layers-fill':title.includes('Telefono')?'phone-fill':title.includes('pagamento')?'credit-card-fill':title.includes('offerta')||title.includes('Offerta')?'grid-fill':'sliders');icon.setAttribute('aria-hidden','true');header.prepend(icon);
 });
 const wrap=document.createElement('div');wrap.className='lq-summary-shell';while(aside.firstChild)wrap.append(aside.firstChild);aside.append(wrap);
 const summary=document.getElementById('lq-summary');const summaryTitle=summary.querySelector('.kol-label');summaryTitle.innerHTML='<i class="bi bi-receipt" aria-hidden="true"></i>Il tuo preventivo';
 const summaryNote=document.createElement('p');summaryNote.className='lq-hint';summaryNote.textContent='Gli importi si aggiornano con i servizi aggiunti.';summaryTitle.after(summaryNote);
 const count=document.getElementById('lq-service-count'),rows=document.getElementById('righeList');
 function update(){const n=rows.querySelectorAll(':scope>.riga-servizio').length;count.textContent=n;root.querySelectorAll('.kol-btn').forEach(btn=>btn.setAttribute('aria-pressed',String(btn.classList.contains('selected'))));root.querySelector('[data-lq-target="lq-summary"]').classList.toggle('ready',n>0);rows.querySelectorAll('button[onclick^="rimuoviRiga"]').forEach(btn=>{btn.title='Rimuovi servizio';btn.setAttribute('aria-label','Rimuovi servizio');});}
 new MutationObserver(update).observe(rows,{childList:true});root.addEventListener('click',()=>queueMicrotask(update));update();
 root.querySelectorAll('[data-lq-target]').forEach(btn=>btn.addEventListener('click',()=>{document.getElementById(btn.dataset.lqTarget)?.scrollIntoView({block:'start',behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth'});}));
 const select=root.querySelector('select[name="cliente_id"]'),search=document.getElementById('lq-search-client'),result=document.getElementById('lq-search-count');
 const options=[...select.options];
 search.addEventListener('input',()=>{const q=search.value.toLocaleLowerCase('it').trim(),selected=select.value;const matches=options.filter((o,i)=>i>0&&(!q||o.textContent.toLocaleLowerCase('it').includes(q)));const filtered=[options[0],...matches];if(selected&&!filtered.some(o=>o.value===selected)){const chosen=options.find(o=>o.value===selected);if(chosen)filtered.splice(1,0,chosen);}select.replaceChildren(...filtered);select.value=selected;result.textContent=q?matches.length+' clienti trovati':'';});
 root.querySelectorAll('#sezione_nuovo input').forEach((input,i)=>{if(!input.id)input.id='lq-new-client-'+i;const label=document.createElement('label');label.htmlFor=input.id;label.className='form-label';label.textContent=input.placeholder;input.before(label);});
 // "Offerta libera" opens/focuses the existing editor; its own Add button retains its handler.
 root.querySelectorAll('button[onclick="aggiungiManuale()"]').forEach(btn=>{if(btn.closest('#sez_manuale'))return;btn.removeAttribute('onclick');btn.addEventListener('click',()=>{document.getElementById('sez_manuale').scrollIntoView({block:'center',behavior:'smooth'});document.getElementById('man_desc').focus({preventScroll:true});});});
 root.querySelectorAll('.lq-actions button').forEach(btn=>{if(btn.type==='submit')btn.setAttribute('aria-label','Salva preventivo come bozza');});
})();
