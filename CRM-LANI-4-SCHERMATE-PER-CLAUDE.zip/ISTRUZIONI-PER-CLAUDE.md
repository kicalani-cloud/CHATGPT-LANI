# Rifinitura delle quattro schermate approvate

Base: archivio crm-v5-SOLO-CODICE.tar.gz inviato il 18/10/2026. Questa consegna conserva il design precedente e modifica solo Clienti Chiamati MyWCM, Chiamate dal Cellulare, Scheda cliente e riquadro Stima Premio della dashboard.

## Integrazione
1. Crea un backup della versione attuale. Confronta i quattro template con quelli in templates/, usando manifest.json per identificare la base. Se ci sono modifiche successive, uniscile senza sovrascriverle.
2. Copia i due nuovi asset static/css/lani-four-views.css e static/js/lani-four-views.js. I template li includono direttamente. Mantieni base.html, lani-refresh.css, lani-workflows.css, lani-layout.js e lani-workflows.js già presenti nell'archivio base.
3. Usa i file in templates/: alcune copie omonime nella radice dell'archivio originale non sono i template effettivamente caricati da Flask. Non sostituire le copie alla cieca.
4. Non modificare app.py, models.py, parser, dashboard_metrics.py, database, configurazione o chiavi. I file backend sono stati verificati identici all'ultimo archivio. Non servono migrazioni né nuove dipendenze.
5. Verifica in staging con dati di prova e il consueto avvio del progetto. Pubblica solo dopo la verifica sul CRM effettivo.

## Cosa cambia
- MyWCM: filtri principali allineati, schede indicatori con icone, tabella compatta, paginazione locale 10/25/50/100 che lavora insieme al filtro giorno; filtri avanzati, richiami, WhatsApp e modale modifica conservati.
- Chiamate: indicatori, intervallo date, riepiloghi operatori, player compatti e pulsanti allineati. CSV apribile in Excel delle righe della pagina visibile; campi testuali neutralizzati contro formule Excel. Impostazioni per mostrare/nascondere dettagli MyWCM. I dettagli completi restano apribili nella riga. Il comando AI spiega l'uso dell'analisi sulla singola registrazione: non avvia analisi massive. Restano i controlli di ruolo esistenti.
- Scheda cliente: informazioni e contratti in alto, storico contatti, punti/opportunità, attività e note sotto come nel riferimento. I nodi originali vengono spostati, non clonati: handler e moduli rimangono quelli esistenti. Copia CF/P.IVA/IBAN. Le note usano il campo cliente.note e la modifica cliente esistente, senza creare un modello di note inesistente. Nessuna attività fittizia aggiunta al CRM.
- Gare: due pannelli principali Mobile/Fisso e quattro pannelli secondari Luce & Gas/CB/Assicurazioni/Protetti, colori e proporzioni della foto. Premi, soglie e totale vengono dalle variabili stima_gara già presenti; nessun importo codificato dalle immagini.

Le foto sono riferimenti grafici: conteggi, percentuali, nomi e importi non sono dati da copiare. Le chiamate mostrano i record restituiti dal backend esistente (massimo 500); non vengono inventati confronti percentuali con periodi non disponibili.

## Verifiche effettuate
91 rotte GET autenticate/anonime: HTTP 200. 90 viste offline: desktop/mobile senza errori JavaScript o scorrimento orizzontale della pagina. Test mirati: filtro giorno MyWCM, intervallo date e reset Chiamate, esportazione CSV, impostazioni colonne, disposizione scheda cliente, ID univoci, apertura modulo contatti. Accesso Chiamate ancora 403 per addetto. Backend invariato byte per byte. Invii, cancellazioni, telefonate reali, AI esterna e audio reali non eseguiti.

La demo offline usa solo dati sintetici e non aggiorna il CRM online.
