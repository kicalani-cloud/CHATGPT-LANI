/* Targeted presentation controls. Original forms, handlers and permissions remain. */
(function(){
 'use strict';
 const sheet=document.querySelector('link[href*="lani-four-views.css"]');if(sheet)document.head.append(sheet);
 const grid=document.getElementById('lani-client-grid');
 if(grid){
  const overview=document.createElement('div');overview.id='lani-client-overview';
  for(const id of ['lani-client-info','lani-client-contracts','storico']){const el=document.getElementById(id);if(el)grid.append(el);}
  for(const id of ['lani-client-points','lani-client-opportunities']){const el=document.getElementById(id);if(el)overview.append(el);}
  grid.append(overview);
  for(const id of ['lani-client-activity','lani-client-notes']){const el=document.getElementById(id);if(el)grid.append(el);}
  const info=document.getElementById('lani-client-info');
  info.querySelectorAll('tr').forEach(row=>{
   const label=row.cells[0]?.textContent.trim();const cell=row.cells[1];
   if(!cell||!['CF','P.IVA','IBAN'].includes(label)||cell.textContent.trim()==='—')return;
   const value=cell.textContent.trim();const btn=document.createElement('button');btn.type='button';btn.className='lani-copy-button';btn.innerHTML='<i class="bi bi-copy"></i>';btn.title='Copia '+label;btn.setAttribute('aria-label','Copia '+label);
   btn.addEventListener('click',async()=>{try{await navigator.clipboard.writeText(value);btn.innerHTML='<i class="bi bi-check-lg"></i>';btn.title='Copiato';setTimeout(()=>{btn.innerHTML='<i class="bi bi-copy"></i>';btn.title='Copia '+label;},1600);}catch{btn.title='Seleziona il testo per copiarlo';}});cell.append(btn);
  });
 }
 const mywcm=document.querySelector('.lani-mywcm-photo');
 if(mywcm){const first=mywcm.children[0],second=mywcm.children[1];const toolbar=document.createElement('div');toolbar.className='lani-mywcm-main-toolbar';mywcm.insertBefore(toolbar,first);toolbar.append(first,second);}
 const table=document.querySelector('.lani-mywcm-table table');
 if(!table)return;
 const rows=[...table.querySelectorAll('tbody tr[id^="row-"]')];const size=document.getElementById('mywcm-size');const day=document.getElementById('filtro-giorno');
 let page=1;
 const numbered=document.createElement('div');numbered.className='lani-four-numbered-pages';document.getElementById('mywcm-page').replaceWith(numbered);
 const empty=document.createElement('tr');empty.id='mywcm-local-empty';const cell=document.createElement('td');cell.colSpan=table.tHead.rows[0].cells.length;cell.className='text-center text-muted py-4';cell.textContent='Nessun cliente per il giorno selezionato.';empty.append(cell);table.tBodies[0].append(empty);
 function render(reset=false){
  if(reset)page=1;
  const filtered=rows.filter(r=>!day.value||r.dataset.data===day.value);const n=Number(size.value);const pages=Math.max(1,Math.ceil(filtered.length/n));page=Math.max(1,Math.min(page,pages));
  rows.forEach(r=>r.hidden=true);filtered.slice((page-1)*n,page*n).forEach(r=>r.hidden=false);empty.hidden=filtered.length>0||rows.length===0;
  document.getElementById('mywcm-range').textContent=`${filtered.length?(page-1)*n+1:0}–${Math.min(page*n,filtered.length)} di ${filtered.length} clienti`;
  document.getElementById('mywcm-prev').disabled=page===1;document.getElementById('mywcm-next').disabled=page===pages;
  numbered.replaceChildren();const choices=new Set([1,pages,page-1,page,page+1]);let last=0;
  for(const p of [...choices].filter(p=>p>=1&&p<=pages).sort((a,b)=>a-b)){
   if(last&&p-last>1){const dot=document.createElement('span');dot.textContent='…';numbered.append(dot);}
   const btn=document.createElement('button');btn.type='button';btn.className='lani-four-page-number'+(p===page?' active':'');btn.textContent=p;btn.setAttribute('aria-label','Pagina '+p);if(p===page)btn.setAttribute('aria-current','page');btn.addEventListener('click',()=>{page=p;render();});numbered.append(btn);last=p;
  }
  const groups=new Map();filtered.forEach(r=>groups.set(r.dataset.operatore||'—',(groups.get(r.dataset.operatore||'—')||0)+1));
  const badges=document.getElementById('riepilogo-badges-mywcm');badges.replaceChildren();
  if(day.value)for(const [name,count] of groups){const span=document.createElement('span');span.className='badge text-bg-light border py-2 px-3';span.textContent=name+': '+count+' clienti';badges.append(span);}
  document.getElementById('box-riepilogo-mywcm').classList.toggle('d-none',!day.value||!groups.size);
 }
 window.filtraGiorno=()=>render(true);day.addEventListener('change',window.filtraGiorno);size.addEventListener('change',()=>render(true));
 document.getElementById('mywcm-prev').addEventListener('click',()=>{page--;render();});document.getElementById('mywcm-next').addEventListener('click',()=>{page++;render();});render();
})();
