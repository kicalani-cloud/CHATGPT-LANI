# Importa PDF — nuova interfaccia con riconoscimento automatico esistente

## Obiettivo
Mantieni l'importazione automatica attuale: il cliente carica il PDF e il parser esistente compila i dati. Non introdurre una scelta iniziale obbligatoria di MNP, CB, ecc. La nuova interfaccia presenta il risultato e consente correzioni opzionali. Il parser e i calcoli commerciali non sono stati modificati.

## Integrazione
Fai prima un backup e confronta la versione installata con quella del progetto. Integra templates/importa_pdf.html e aggiungi gli altri file della cartella crm-v5. Mantieni base.html, i modelli, i parser e le modifiche già fatte nelle altre pagine. Non sostituire tutto app.py.

Applica solo app-import-review.patch, oppure aggiungi dopo l'inizializzazione del LoginManager queste istruzioni:
    import import_review
    import_review.register(app)
Il modulo aggiunge esclusivamente GET /api/importa-pdf/cliente, protetto dal login, per cercare corrispondenze esatte con gli stessi identificativi e priorità del salvataggio esistente (prima P.IVA, altrimenti CF). Non scrive nel database. Se l'endpoint è già presente, non registrarlo due volte. Il file app.py di partenza ha SHA256: cae96a0295451528ae0bbb9ca1c65bf819f9510d4b7ac84cc50275a1261330d9.

Non servono migrazioni o nuove dipendenze Python. Distribuisci anche i due moduli PDF.js e la relativa licenza, mantenendo i percorsi static/vendor/pdfjs/. Il controller carica PDF.js e worker dalla stessa origine, senza CDN durante l'utilizzo. Verifica i MIME .mjs se il server statico non li gestisce già. PDF.js 4.10.38 proviene da https://cdn.jsdelivr.net/npm/pdfjs-dist@4.10.38/; licenza Apache 2.0 inclusa. Il rendering usa isEvalSupported:false.

## Comportamento
- Carica → Verifica dati → Conferma importazione. Nessun pulsante bozza senza un flusso backend che la gestisca.
- PDF originale con navigazione pagine e zoom a sinistra; cliente e dati modificabili a destra. Ulteriori dettagli richiudibili.
- Cliente esistente/nuovo riconosciuto con la verifica esatta del CRM, senza deduzioni dal solo numero di telefono. Duplicati dell'identificativo segnalati prima del salvataggio.
- Per CB restano evento, cluster, linea e telefono, con le regole e i punti originali. Il tipo mostrato deriva dai dati già estratti e dai campi del CRM, non da una nuova categoria salvata separatamente.
- Numero da portare e numero della SIM restano distinti; telefono e IMEI hanno la propria sezione. Fisso, energia e SIM usano i campi già presenti.
- Prezzo dispositivo: mantenuto un solo campo con name=prezzo_smartphone; il campo del calcolatore viene sincronizzato, evitando valori duplicati nel POST.
- Verifica AI facoltativa: mostra la proposta, poi l'utente può applicarla. Non modifica automaticamente i campi prima di tale azione. Una risposta AI di un documento precedente non viene applicata al successivo.
- Il salvataggio richiama la funzione originale validaESalva e lo stesso endpoint esistente. La conferma richiama l'attenzione sulla data di attivazione: l'interfaccia non prova che la linea sia già attiva.

## Verifiche
Pagina reale renderizzata e controllo cliente autenticato: corrispondenza, nuovo, mancante, duplicati e accesso anonimo verificati. Tre PDF forniti dall'utente letti dal parser senza salvare clienti o contratti. Sei flussi UI sintetici testati: MNP, CB cambio offerta, CB + telefono, fisso, sostituzione SIM, Luce + Gas. Verificati payload prezzo unico, riepilogo e conferma, chiamata al salvataggio originale simulata, paginazione/zoom PDF.js reale, proposta/applicazione AI con risposta simulata, desktop/mobile senza overflow. L'API AI esterna e salvataggi di contratti reali non sono stati eseguiti.

Prima del rilascio verifica su una copia del CRM con dati di prova: upload reale, corrispondenza cliente, calcoli e salvataggio per le operazioni utilizzate nel negozio. La nuova grafica conserva anche gli eventuali limiti del parser precedente: non considerarli corretti dalla sola interfaccia.

## Demo separata
La demo offline propone sei documenti sintetici già riconosciuti. I pulsanti degli esempi esistono solo nella demo, non nel CRM. Le anteprime dei PDF dimostrativi usano pagine renderizzate localmente per aprirsi anche con file:// su Mac. Nel CRM il PDF originale viene renderizzato da PDF.js. La demo non legge nuovi PDF con il parser Python e non salva nel CRM.
