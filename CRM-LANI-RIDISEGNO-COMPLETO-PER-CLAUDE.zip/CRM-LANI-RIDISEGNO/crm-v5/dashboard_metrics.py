"""Read-only dashboard series; preserve the CRM's existing point rules."""
from calendar import monthrange
from datetime import date, datetime

MONTHS = ('Gen', 'Feb', 'Mar', 'Apr', 'Mag', 'Giu', 'Lug', 'Ago', 'Set', 'Ott', 'Nov', 'Dic')
GA_KEYS = ('mobile', 'fisso', 'luce_gas', 'assicurazione')


def shift_month(value, offset):
    index = value.year * 12 + value.month - 1 + offset
    year, month = divmod(index, 12)
    return date(year, month + 1, 1)


def as_date(value):
    return value.date() if isinstance(value, datetime) else value


def comparison_windows(selected, today):
    selected = selected.replace(day=1)
    previous = shift_month(selected, -1)
    current_month = today.replace(day=1)
    if selected == current_month:
        end = date(selected.year, selected.month, today.day)
        previous_day = min(today.day, monthrange(previous.year, previous.month)[1])
        previous_end = date(previous.year, previous.month, previous_day)
        from datetime import timedelta
        return selected, end + timedelta(days=1), previous, previous_end + timedelta(days=1), 'partial'
    return selected, shift_month(selected, 1), previous, selected, 'future' if selected > current_month else 'complete'


def variation(current, previous, unavailable=False):
    delta = round(current - previous, 2)
    if unavailable:
        return dict(current=current, previous=previous, delta=None, percent=None, kind='future', text='Non iniziato')
    if previous == 0:
        percent = 0.0 if current == 0 else None
    else:
        percent = (current - previous) / abs(previous) * 100
    kind = 'new' if previous == 0 and current != 0 else 'up' if delta > 0 else 'down' if delta < 0 else 'flat'
    if kind == 'new':
        text = 'Nuovo'
    elif percent == 0:
        text = '0%'
    elif abs(percent) < 0.1:
        text = ('+' if percent > 0 else '−') + '<0,1%'
    else:
        amount = ('%g' % round(abs(percent), 1)).replace('.', ',')
        text = ('+' if percent > 0 else '−') + amount + '%'
    return dict(current=current, previous=previous, delta=delta, percent=percent, kind=kind, text=text)


def summarize_contracts(contracts, start, end):
    result = dict(ga={k: 0.0 for k in GA_KEYS}, cb=dict(mobile=0.0, fisso=0.0, totale=0.0), activations=0)
    for contract in contracts:
        stamp = as_date(contract.data_attivazione or contract.created_at)
        if stamp is None or not start <= stamp < end:
            continue
        category = contract.categoria
        if contract.tipo in ('mobile', 'fisso') and category is not None and category not in ('cb', 'sim_sostitutiva', 'cambio_metodo_pagamento'):
            result['activations'] += 1
        if contract.stato != 'attivo':
            continue
        points = float(contract.punti_ga or 0)
        if category == 'cb':
            if contract.tipo in ('mobile', 'fisso'):
                result['cb'][contract.tipo] += points
            result['cb']['totale'] += points
        elif contract.tipo in ('luce', 'gas', 'luce_gas'):
            result['ga']['luce_gas'] += 1
        elif contract.tipo in GA_KEYS:
            result['ga'][contract.tipo] += points
    result['ga'] = {k: round(v, 2) for k, v in result['ga'].items()}
    result['cb'] = {k: round(v, 2) for k, v in result['cb'].items()}
    return result


def build_dashboard_metrics(selected, today=None):
    from models import db, Contratto, Cliente, LeadCaldo
    from sqlalchemy.orm import selectinload
    today = today or date.today()
    selected = selected.replace(day=1)
    start, end, previous_start, previous_end, mode = comparison_windows(selected, today)
    history_start = shift_month(selected, -5)
    history_end = shift_month(selected, 1)
    # Fetch once. data_attivazione takes precedence over created_at, as in the CRM.
    contracts = Contratto.query.options(selectinload(Contratto.cliente)).filter(db.or_(
        db.and_(Contratto.data_attivazione >= history_start, Contratto.data_attivazione < history_end),
        db.and_(Contratto.data_attivazione.is_(None), Contratto.created_at >= history_start, Contratto.created_at < history_end),
    )).all()
    current = summarize_contracts(contracts, start, end)
    previous = summarize_contracts(contracts, previous_start, previous_end)
    periods = []
    for offset in range(-5, 1):
        month = shift_month(selected, offset)
        month_end = end if offset == 0 and mode == 'partial' else shift_month(month, 1)
        item = summarize_contracts(contracts, month, month_end)
        full_label = f'{MONTHS[month.month - 1]} {month.year}'
        if offset == 0 and mode == 'partial':
            full_label += f' · 1–{today.day}'
        item.update(label=MONTHS[month.month - 1], full_label=full_label, key=month.isoformat())
        periods.append(item)
    def creations(model, column, lower, upper):
        return model.query.filter(column >= lower, column < upper).count()
    new_clients = creations(Cliente, Cliente.created_at, start, end)
    old_clients = creations(Cliente, Cliente.created_at, previous_start, previous_end)
    new_leads = creations(LeadCaldo, LeadCaldo.data_creazione, start, end)
    old_leads = creations(LeadCaldo, LeadCaldo.data_creazione, previous_start, previous_end)
    unavailable = mode == 'future'
    comparisons = {k: variation(current['ga'][k], previous['ga'][k], unavailable) for k in GA_KEYS}
    comparisons.update(clienti=variation(new_clients, old_clients, unavailable),
                       attivazioni=variation(current['activations'], previous['activations'], unavailable),
                       lead=variation(new_leads, old_leads, unavailable))
    if mode == 'partial':
        period_label = f'1–{today.day} {MONTHS[selected.month - 1]} vs 1–{(previous_end - previous_start).days} {MONTHS[previous_start.month - 1]}'
    else:
        period_label = f'{MONTHS[selected.month - 1]} {selected.year} vs {MONTHS[previous_start.month - 1]} {previous_start.year}'
    return dict(current=current, previous=previous, comparisons=comparisons,
                labels=[p['label'] for p in periods], full_labels=[p['full_label'] for p in periods],
                ga_series={k: [p['ga'][k] for p in periods] for k in GA_KEYS},
                cb_series={k: [p['cb'][k] for p in periods] for k in ('mobile', 'fisso')},
                period_label=period_label, mode=mode,
                new_clients=new_clients, new_leads=new_leads,
                caption='Punti mensili dei contratti attualmente attivi. Mese in corso parziale.' if mode == 'partial' else 'Punti mensili dei contratti attualmente attivi.')
