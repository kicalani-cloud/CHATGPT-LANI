# Dashboard e grafica CRM Lani

Integra questi file nel CRM attuale, conservando tutte le modifiche funzionali già fatte. Prima crea un backup e controlla il diff. Non distribuire direttamente senza verifica.

La cartella crm contiene i sei file aggiornati. Unisci dashboard.html, base.html, lani-refresh.css e lani-layout.js con le eventuali modifiche successive; aggiungi dashboard_metrics.py e lani-dashboard.js. Il layout comune mantiene la grafica approvata sulle altre pagine.

Per app.py applica SOLO app-dashboard.patch o integra manualmente le quattro righe indicate: importa build_dashboard_metrics dentro dashboard(), calcola dashboard_visual con oggi e oggi_reale, passa dashboard_visual al render_template. Non sostituire tutto app.py: preserva plafond, scanner e ogni altra modifica esistente. Il file di partenza della patch ha SHA256: 700cdd9df226c06ba70cdd1a3c1c576fbce7dc618c442c13b20bacbd3ed85c93.

Non servono migrazioni né nuove dipendenze: usa Flask/SQLAlchemy e Chart.js già presenti. Il modulo legge i dati; non li modifica. Mantieni il caricamento di Chart.js prima di lani-dashboard.js.

## Regole del confronto
- Mese corrente: dal giorno 1 a oggi rispetto agli stessi giorni del mese precedente; il limite si adatta ai mesi più corti.
- Mesi conclusi: mese intero contro mese intero precedente, anche tra dicembre e gennaio.
- Formula: (attuale - precedente) / precedente × 100. Una discesa da 100 a 80 mostra −20% rosso; una salita a 120 mostra +20% verde; parità 0%.
- Precedente zero: mostra Nuovo se ora il valore è positivo, 0% se entrambi sono zero. Nessuna percentuale inventata. Mesi futuri: Non iniziato.
- Le variazioni delle schede Clienti, Contratti e Lead riguardano i nuovi eventi del periodo, specificati sotto il totale. Le scadenze non hanno variazioni storiche inventate.
- I grafici usano sei mesi di dati reali; il mese corrente è parziale. Il Customer Base storico conta contratti attualmente attivi datati in quei mesi: non ricostruisce stati storici non registrati.
- La demo usa dati sintetici, comprese crescite negative: non importarli nel CRM reale.

## Verifica prima della consegna
Esegui tests/test_dashboard_metrics.py con le dipendenze del CRM, verifica dashboard autenticata, selezione mese/anno, segni e valori dei confronti, grafici e visualizzazione mobile. Controlla le altre pagine dopo l'unione del layout comune. Lascia invariati i calcoli della gara e i permessi esistenti. Questo pacchetto non è stato installato sul sito online.
