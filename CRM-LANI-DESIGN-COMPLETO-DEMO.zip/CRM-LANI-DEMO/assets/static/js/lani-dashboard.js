(function () {
  'use strict';
  const element = document.getElementById('lani-dashboard-data');
  if (!element || typeof Chart === 'undefined') return;
  const data = JSON.parse(element.textContent);
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const number = new Intl.NumberFormat('it-IT', {maximumFractionDigits: 2});
  const colors = {mobile: '#ff4c68', fisso: '#0876ff', luce_gas: '#f5ac00', assicurazione: '#16bb7f'};
  function area(context, color) {
    const chart = context.chart;
    const bounds = chart.chartArea;
    if (!bounds) return color + '15';
    const fill = chart.ctx.createLinearGradient(0, bounds.top, 0, bounds.bottom);
    fill.addColorStop(0, color + '44');
    fill.addColorStop(1, color + '03');
    return fill;
  }
  document.querySelectorAll('[data-lani-spark]').forEach(function (canvas) {
    const key = canvas.dataset.laniSpark;
    const color = colors[key];
    new Chart(canvas, {
      type: 'line',
      data: {labels: data.full_labels, datasets: [{data: data.ga_series[key], borderColor: color,
        backgroundColor: context => area(context, color), fill: true, borderWidth: 1.8,
        tension: 0.35, pointRadius: 0, pointHoverRadius: 3, pointHitRadius: 9}]},
      options: {responsive: true, maintainAspectRatio: false, animation: reducedMotion ? false : {duration: 350},
        interaction: {intersect: false, mode: 'index'},
        plugins: {legend: {display: false}, tooltip: {displayColors: false, callbacks: {
          label: context => number.format(context.parsed.y)
        }}}, scales: {x: {display: false}, y: {display: false, beginAtZero: true}}, layout: {padding: 2}}
    });
  });
  const canvas = document.getElementById('lani-cb-trend');
  if (canvas) {
    new Chart(canvas, {
      type: 'line',
      data: {labels: data.labels, datasets: [
        {label: 'CB Mobile', data: data.cb_series.mobile, borderColor: '#9000ff', backgroundColor: context => area(context, '#9000ff'), pointBackgroundColor: '#9000ff'},
        {label: 'CB Fisso', data: data.cb_series.fisso, borderColor: '#0876ff', backgroundColor: context => area(context, '#0876ff'), pointBackgroundColor: '#0876ff'}
      ].map(series => Object.assign(series, {fill: true, tension: 0.3, borderWidth: 2, pointRadius: 3,
        pointBorderWidth: 1, pointBorderColor: '#fff', pointHoverRadius: 5}))},
      options: {responsive: true, maintainAspectRatio: false, animation: reducedMotion ? false : {duration: 400},
        interaction: {intersect: false, mode: 'index'},
        plugins: {legend: {display: false}, tooltip: {callbacks: {
          title: items => items.length ? data.full_labels[items[0].dataIndex] : '',
          label: item => item.dataset.label + ': ' + number.format(item.parsed.y) + ' punti'
        }}}, scales: {
          x: {grid: {color: '#edf1f8', drawTicks: false}, border: {display: false}, ticks: {font: {size: 10}, color: '#7585a0'}},
          y: {beginAtZero: true, grid: {color: '#e9eef7', drawTicks: false}, border: {display: false},
            ticks: {maxTicksLimit: 5, font: {size: 10}, color: '#7585a0', callback: value => number.format(value)}}
        }}
    });
  }
})();
