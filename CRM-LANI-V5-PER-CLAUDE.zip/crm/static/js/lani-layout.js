/* Shared layout refinements: preserve the original controls and event handlers. */
(function () {
  'use strict';
  const actions = document.getElementById('lani-header-actions');
  const mobileHost = document.getElementById('lani-mobile-actions');
  const desktopHost = actions && actions.parentElement;
  const breakpoint = window.matchMedia('(max-width: 768px)');
  if (actions && mobileHost && desktopHost) {
    const marker = document.createComment('Desktop page actions');
    desktopHost.insertBefore(marker, actions);
    function placeActions() {
      if (breakpoint.matches) {
        if (actions.parentElement !== mobileHost) mobileHost.appendChild(actions);
      } else if (actions.parentElement !== desktopHost) {
        desktopHost.insertBefore(actions, marker.nextSibling);
      }
    }
    placeActions();
    if (breakpoint.addEventListener) breakpoint.addEventListener('change', placeActions);
    else breakpoint.addListener(placeActions);
  }
  document.querySelectorAll('.sidebar-nav a.active').forEach(function (a) {
    a.setAttribute('aria-current', 'page');
  });
  const overlay = document.getElementById('mobileMenuOverlay');
  const menuButton = document.getElementById('btnMobileMenu');
  const closeButton = document.getElementById('btnMobileMenuClose');
  let returnFocus = null;
  if (overlay && menuButton) {
    const syncMenu = function () {
      const open = overlay.classList.contains('open');
      menuButton.setAttribute('aria-expanded', String(open));
      if (open) {
        returnFocus = document.activeElement;
        if (closeButton) closeButton.focus();
      } else if (returnFocus && returnFocus.isConnected) {
        returnFocus.focus();
        returnFocus = null;
      }
    };
    menuButton.setAttribute('aria-expanded', String(overlay.classList.contains('open')));
    new MutationObserver(syncMenu).observe(overlay, {attributes: true, attributeFilter: ['class']});
    document.addEventListener('keydown', function (event) {
      if (event.key === 'Escape' && overlay.classList.contains('open') && closeButton) closeButton.click();
    });
  }
})();
