# CRM Lani — rifinitura grafica completa

Consegna cumulativa dei template e degli asset grafici, basata su crm-v5-SOLO-CODICE.tar.gz del 18 ottobre 2026. I file sono quelli effettivi sotto templates/, non le copie omonime nella radice.

## Integrazione sul CRM esistente
Esegui backup e confronta manifest.json con i file installati. Integra i template e gli asset mantenendo tutte le modifiche successive del cliente. Non copiare alla cieca su una versione diversa. Non sostituire il backend, database, modelli, parser, configurazione, chiavi o upload. Non sono richieste migrazioni.

Il sistema grafico condiviso è in lani-refresh.css e lani-complete.css. Il secondo rifinisce viste secondarie, moduli, tabelle, finestre, report e pulsanti; conserva i layout specifici già approvati. base.html carica gli asset. Le viste specializzate usano anche lani-four-views, lani-workflows, lani-import e lani-quote. Le regole relative al pannello premi compatto sono mantenute.

WhatsApp e Social Coach conservano handler, selezione destinatari, API, pubblicazioni e pianificazione attuali. Questa consegna modifica presentazione e testi, non abilita nuove integrazioni. Per Social Coach servono le credenziali Meta/TikTok già configurate sul server.

Nuovo preventivo mantiene form e endpoint originali, listini, selezioni progressive, simulatore, righe, calcoli, anteprima e invio. Aggiunti ricerca locale clienti, riepilogo laterale e indicatore servizi. Offerta libera porta al relativo editor prima di aggiungere la riga. Il campo valido_fino già esistente viene mostrato, ma la route originale non lo persiste: questa consegna grafica non cambia il comportamento backend. Non dichiararlo risolto. Il salvataggio resta come bozza, non un contratto attivato.

Importa PDF mantiene riconoscimento automatico e dati estratti subito visibili. Includere PDF.js con licenza e MIME corretti per .mjs. Applicare soltanto app-import-review.patch se il modulo non è già registrato: aggiunge la verifica identità cliente in sola lettura. Non duplicare la registrazione. Il parser automatico esistente non è stato sostituito né corretto. Per le spiegazioni complete vedere le precedenti consegne Importa PDF.

Il file dashboard_metrics.py è fornito perché richiesto dal codice di partenza. La base ricevuta già lo richiama; non duplicare route o chiamate. Manifest confronta le impronte rispetto all'ultimo archivio caricato. Questa consegna non contiene app.py completo.

## Verifica
91 pagine GET del CRM sintetico renderizzate con HTTP 200. Demo di 90 viste verificata a 1440 e 390 pixel per errori JavaScript e overflow. Verificati Nuovo preventivo: cliente nuovo, righe, canone, attivazione, serializzazione FormData e rimozione; WhatsApp: passaggio a numero diretto. Verifiche solo locali, nessun invio, pubblicazione social, chiamata o cancellazione reale. Prima del rilascio controllare i flussi con dati di prova su una copia del CRM installato.

La demo offline è distinta dai sorgenti: i comandi server, le API social e AI e i salvataggi non sono disponibili offline. Non installare i dati dimostrativi sul CRM. Nessun database o segreto incluso.
