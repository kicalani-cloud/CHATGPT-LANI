# CRM Lani — ridisegno delle sezioni rimaste, consegna cumulativa

Base: archivio crm-v5-SOLO-CODICE.tar.gz del 18 ottobre 2026. La nuova consegna comprende i precedenti ritocchi a dashboard, scheda cliente, badge, WhatsApp, Importa PDF e Nuovo preventivo. Non occorre installare una serie di ZIP precedenti.

## Cosa cambia
71 template delle sezioni rimaste hanno ora una dichiarazione di layout esplicita e un'intestazione dedicata. La mappa delle schermate riporta finalità, icona, colore e tipo di spazio di lavoro. Sono stati rifiniti anche login e scanner mobile, autonomi rispetto a base.html. In totale 82 template HTML differiscono dall'archivio base; la demo copre 90 rotte, perché alcuni template servono creazione e modifica.

I layout comuni sono distinti per elenchi, moduli, dettaglio, report, composizione, impostazioni, magazzino, calendario, documenti, importazione e collegamenti ai portali. Il codice non è un secondo CRM: usa i dati, i moduli e le azioni originali. Non dichiarare che ogni pagina possiede un design indipendente dai componenti condivisi.

Contratti e Clienti: intestazione, avatar ricavati dai nomi, filtri e schede, tabelle, badge. Magazzino e accessori: riepiloghi calcolati sulle collezioni effettive, disponibilità e prezzi. Preventivi: riepilogo delle proposte mostrate e degli stati. Assistenza: priorità, ticket e pannelli. Impostazioni: collegamenti alle sezioni esistenti e pannelli. Composer AI: area configurazione e risultato. Report: pannelli e grafici esistenti. Calendari, gare, cassa, campagne e strumenti secondari seguono lo stesso linguaggio visivo.

La ricerca aggiunta alle tabelle è locale e dice esplicitamente «Cerca nelle righe caricate»: non sostituisce filtri, paginazione o ricerca del database. Non viene applicata a tabelle con campi di modifica. I conteggi indicano righe presenti o collezioni mostrate, non risultati globali inventati. I collegamenti alle sezioni puntano alle schede già presenti; nessun riepilogo è stato ottenuto da API esterne.

## Integrazione
Fai backup e confronto con manifest.json. Integra i file in crm-v5/templates/ e gli asset statici, senza sovrascrivere modifiche più recenti. Le copie omonime nella radice del vecchio archivio non sono i template usati da Flask. base.html deve caricare lani-redesign.css e lani-redesign.js insieme ai precedenti asset; non caricarli due volte.

Non sostituire app.py completo, models.py, parser, database, upload, chiavi, segreti o configurazione. Il backend resta quello dell'archivio base; l'unica patch inclusa è la registrazione in sola lettura di import_review, già prevista dalla consegna Importa PDF. Applicarla solo se non presente. dashboard_metrics.py è richiesto dal backend di partenza e viene incluso; non duplicare route o elaborazioni.

Non servono migrazioni o nuove dipendenze Python per il redesign. Il parser PDF, i calcoli, l'invio WhatsApp tramite apertura delle chat e le integrazioni social restano quelli esistenti. L'anteprima WhatsApp non prova l'invio. In Nuovo preventivo il campo valido_fino preesistente è mostrato ma il backend originale non lo persiste: il limite non è corretto da questo lavoro grafico. Il salvataggio della proposta resta come bozza. PDF.js deve essere distribuito con i due moduli .mjs e la licenza inclusa.

## Verifiche e limiti
91 richieste alle pagine del CRM di prova con HTTP 200; 90 viste offline su desktop e mobile, senza errori JavaScript o overflow di pagina. Metodi, destinazioni e campi nominati dei 437 moduli risultano identici alla precedente consegna. Verificati navigazione cliente → dettaglio → modifica, cambio privato/business, tab followup e finestra firma. Ulteriori verifiche: ricerca locale nelle tabelle, ancore delle impostazioni, finestre di modifica utente e importazione IMEI, grafici Analytics con dati sintetici.

Il sito online restituisce 403 Domain forbidden da questo ambiente: non è stato aggiornato né collaudato con una sessione dell'utente. I controlli non provano tutte le combinazioni di salvataggio o permessi del CRM installato. Prima del rilascio verificare su una copia del server con dati di prova: creazione/modifica cliente e contratto, filtri e paginazione, preventivi, import PDF, cassa, turni e integrazioni. Non inviare messaggi o pubblicare post reali durante il controllo grafico.

## Demo
Estrai tutto lo ZIP DEMO e apri index.html. Il catalogo include tutte le 90 viste. È una fotografia con dati sintetici; salvataggi, AI, filtri server, audio reali e servizi social richiedono il backend. Il grafico Analytics usa una risposta in sola lettura del database sintetico, inclusa solo nella demo. I collegamenti tra record portano alla scheda dimostrativa del relativo tipo, non ai dati di produzione. Non installare i fixture della demo sul server.
